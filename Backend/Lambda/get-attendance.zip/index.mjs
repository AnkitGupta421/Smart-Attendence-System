import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";

const ddbClient = new DynamoDBClient({ region: "ap-south-1" });
const docClient = DynamoDBDocumentClient.from(ddbClient);
const HISTORY_TABLE_NAME = "AttendanceHistory"; // The name of your history table

export const handler = async (event) => {
    // Standard headers to allow your web page to call this API
    const corsHeaders = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
    };

    // Respond to pre-flight CORS requests
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers: corsHeaders, body: '' };
    }

    try {
        // Get subject and semester from the URL (e.g., .../get-history?subject=Chemistry&semester=1)
        const subject = event.queryStringParameters?.subject;
        const semester = event.queryStringParameters?.semester;

        if (!subject || !semester) {
            return {
                statusCode: 400,
                headers: corsHeaders,
                body: JSON.stringify({ message: "Missing 'subject' or 'semester' query parameters." }),
            };
        }

        // Scan the DynamoDB table to find all items matching the subject and semester
        const scanCommand = new ScanCommand({
            TableName: HISTORY_TABLE_NAME,
            FilterExpression: "subject = :subj AND semester = :sem",
            ExpressionAttributeValues: {
                ":subj": subject,
                ":sem": parseInt(semester, 10), // Ensure semester is a number
            },
        });

        const result = await docClient.send(scanCommand);
        
        // Sort the results by timestamp, newest first
        const sortedItems = result.Items.sort((a, b) => b.timestamp - a.timestamp);

        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify(sortedItems),
        };

    } catch (error) {
        console.error("Error fetching attendance history:", error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    }
};